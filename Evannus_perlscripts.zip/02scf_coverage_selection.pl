#!/usr/bin/perl -w

=head1 Name

	02scf_coverage_selection.pl

=head1 Description

	This script was designed to:
		selecting scaffolds whose coverage above the cutoff, according to SPAdes assembled genome scafford file.

=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2016/7/21

=head1 Usage

	perl 02scf_coverage_selection.pl  <genome file>  <coverage_cutoff>  <scaffold_length_cutoff>

=head1 Example
  
	perl 02scf_coverage_selection.pl  Str.sul_scaffolds_nobac_nomito_noredundancy.fasta  2  400

=cut

use strict;
die `pod2text $0` unless (@ARGV == 3);
my $file1=$ARGV[0];
my $cov_cutoff=$ARGV[1];
my $len_cutoff=$ARGV[2];


print STDERR "\nLoading genome sequences in fasta format...\n";
open(GENOME, $file1) or die "Cannot open file:$!";

############ Show Progress ############
my $lines_total=0;
my $lines=0;
my $percent2=0;
foreach (<GENOME>) {
	$lines_total++;
}
close GENOME;
#######################################

####################### Hashing Genome file ###########################
open(GENOME, $file1) or die "Cannot open file:$!";

my %genome;
my $id="";

while (<GENOME>){
	############ Show Progress ############
	$lines++;
	my $percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	
	if (/^\>(.+)\n/){
		$id=$1;
		next;
	} else {
		chomp $_;
		$genome{$id}.=$_;
	}
}
close GENOME;

######################################################################

my $filename=$file1;
$filename=~s/\.\w+?$//;

open(OUT1, ">$filename\.coverage$cov_cutoff\.len$len_cutoff\.fasta") or die "Cannot output to file:$!";

####################### Separating Augustus output file ###########################
print STDERR "\nSelecting scaffolds whose coverage above the cutoff \[$cov_cutoff\]...\n";

open(GENOME, $file1) or die "Cannot open file:$!";
$lines=0;
$percent2=0;

while (<GENOME>){
	############ Show Progress ############
	$lines++;
	my $percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	
	if (/\>(.+?cov\_(\d+\.\d+).*)\n/) {
		my $id=$1;
		my $cov=int($2);
		print OUT1 "\>$id\n$genome{$id}\n" if ($cov>=$cov_cutoff && length($genome{$id})>=$len_cutoff);
	}
}

print STDERR "\nJob finished!\n\n";


