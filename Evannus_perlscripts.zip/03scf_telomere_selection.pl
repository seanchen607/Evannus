#!/usr/bin/perl -w

=head1 Name

	03scf_telomere_selection.pl

=head1 Description

	This script was designed to:
		selecting scaffolds who contains telomere sequences "CCCCAAAACCCCAAAACCCC", according to SPAdes assembled genome scafford file.

=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2016/7/21

=head1 Usage

	perl 03scf_telomere_selection.pl  <genome file>  <output_dir>

=head1 Example
  
	perl 03scf_telomere_selection.pl  Str.sul_scaffolds_nobac_nomito_noredundancy.fasta  ../03_2containsTelomere/

=cut

use strict;
die `pod2text $0` unless (@ARGV == 2);
my $file1=$ARGV[0];
my $dir=$ARGV[1];

print STDERR "\nLoading genome sequences in fasta format...\n";
open(GENOME, $file1) or die "Cannot open file:$!";

############ Show Progress ############
my $lines_total=0;
my $lines=0;
my $percent2=0;
foreach (<GENOME>) {
	$lines_total++;
}
close GENOME;
#######################################

####################### Disserting Scaffold file ###########################
open(GENOME, $file1) or die "Cannot open file:$!";

$file1=~s/^.+\///;
$file1=~s/\.\w+$//;
$dir=~s/\/$//;
open(OUT1, ">$dir\/$file1\_Telomere.FR.fasta") or die "Cannot open file:$!";
open(OUT2, ">$dir\/$file1\_Telomere.F.fasta") or die "Cannot open file:$!";
open(OUT3, ">$dir\/$file1\_Telomere.R.fasta") or die "Cannot open file:$!";
open(OUT4, ">$dir\/$file1\_Telomere.none.fasta") or die "Cannot open file:$!";

my $seq="";
my $id="";

while (<GENOME>){
	############ Show Progress ############
	$lines++;
	my $percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	
	if (/^\>/ or eof){
		if ($seq~~/(CCCCAAAACCCCAAAACCCC(\w+)GGGGTTTTGGGGTTTTGGGG)/i) {
			$seq=$1;
			print OUT1 ">$id\n$seq\n" if $id;
		} elsif ($seq~~/(CCCCAAAACCCCAAAACCCC(\w+))/i) {
			$seq=$1;
			print OUT2 ">$id\n$seq\n" if $id;
		} elsif ($seq~~/((\w+)GGGGTTTTGGGGTTTTGGGG)/i) {
			$seq=$1;
			print OUT3 ">$id\n$seq\n" if $id;
		} else {
			print OUT4 ">$id\n$seq\n" if $id;
		}
		($id) = /^\>(.+?)\n/;
		$seq="";
		next;
	} else {
		chomp $_;
		$seq.=$_;
	}
}
close GENOME;

######################################################################

print STDERR "\nJob finished!\n\n";


