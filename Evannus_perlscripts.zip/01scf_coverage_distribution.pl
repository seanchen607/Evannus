#!/usr/bin/perl -w

=head1 Name

	01scf_coverage_distribution.pl

=head1 Description

	This script was designed to:
		disserting coverage distribution, according to SPAdes assembled genome scafford file.

=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2016/7/21

=head1 Usage

	perl 01scf_coverage_distribution.pl  <genome file>

=head1 Example
  
	perl 01scf_coverage_distribution.pl  Str.sul_scaffolds_nobac_nomito_noredundancy.fasta

=cut

use strict;
die `pod2text $0` unless (@ARGV == 1);
my $file1=$ARGV[0];

print STDERR "\nLoading genome sequences in fasta format...\n";
open(GENOME, $file1) or die "Cannot open file:$!";

############ Show Progress ############
my $lines_total=0;
my $lines=0;
my $percent2=0;
foreach (<GENOME>) {
	$lines_total++;
}
close GENOME;
#######################################
my $filename=$file1;

open(OUT1, ">$filename\.coverage") or die "Cannot output to file:$!";

####################### Separating Augustus output file ###########################
print STDERR "\nDisserting scaffold coverage...\n";

open(GENOME, $file1) or die "Cannot open file:$!";

my %coverage;
my $max_cov=0;
while (<GENOME>){
	if (/cov\_(\d+)/) {
		my $cov=int($1);
		$coverage{$cov}++;
		$max_cov=$cov if $max_cov<$cov;
	}
}

for (my $i=1; $i<=$max_cov; $i++) {
	if ($coverage{$i}) {
		print OUT1 "$i\t$coverage{$i}\n";
	} else {
		print OUT1 "$i\t0\n";
	}
}
print STDERR "\nJob finished!\n\n";


