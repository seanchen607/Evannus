#!/usr/bin/perl -w

=head1 Name

	07frameshifting_detect_BLASTX_tab.pl

=head1 Description

	This script was designed to detect frameshifting events from a BLASTX tab file:
	(1) Cutoff: BLASTX E-value <= 1e-5 [insured by BLASTX]
	(2) Frame number of the best BLASTX hit >= 2;
	(3) Distance between two adjacent frames <= 10 bp [length of most introns is ~25 bp]


=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2017/12/21

=head1 Usage

	perl 07frameshifting_detect_BLASTX_tab.pl  <input_file BLASTX tab>  <output file1 frameshifting BLASTX tab>  <output file2 frameshifting adjacent region>  <frame_distance>

=head1 Example
  
	perl 07frameshifting_detect_BLASTX_tab.pl  ./Strombidium_sulcatum_scaffolds.blastx.tab  ./Strombidium_sulcatum_scaffolds.blastx.tab_frameshifting.tab  ./Strombidium_sulcatum_scaffolds.blastx.tab_frameshifting.list  10

=cut

use strict;
die `pod2text $0` if (@ARGV != 4);

#######################################

print STDERR "\nDetect frameshifting events from a BLASTX tab file...\n";

############ Show Progress ############
my $lines_total;
my $lines;
my $percent;
my $percent2;
{
open FILE1, $ARGV[0];
foreach (<FILE1>) {
	$lines_total++;
}
close FILE1;
$lines=0;
$percent2=0;
}
#######################################

open OUT1, ">". $ARGV[1];
open OUT2, ">". $ARGV[2];
print OUT1 "qseqid	sseqid	pident	length	mismatch	gapopen	qstart	qend	sstart	send	evalue	bitscore	qframe	sframe\n";
print OUT2 "transcript_id\tadjacent_start\tadjacent_end\tframeshifting_type\n";
open FILE1, $ARGV[0];
my $frame_distance=$ARGV[3];
my $flag=0;
my %fasta;
my %data;
my $line_last;
my $qseqid_last;
my $sseqid_last;
my $qstart_last;
my $qend_last;
my $sstart_last;
my $send_last;
my $qframe_last;
my $frameshifting_type;
my $adjacent_start;
my $adjacent_end;
my $flag = 0;

foreach (<FILE1>) {
	############ Show Progress ############
	$lines++;
	$percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	my $line = $_;
	my @ar = split /\t/, $_;
	my $qseqid = $ar[0];
	my $sseqid = $ar[1];
	my $qstart = $ar[6];
	my $qend = $ar[7];
	my $sstart = $ar[8];
	my $send = $ar[9];
	my $qframe = $ar[12];
	# print STDERR $qseqid . "\n";
	if ($qseqid_last && $qseqid_last eq $qseqid && $sseqid_last && $sseqid_last eq $sseqid && $qstart && $qend && $sstart && $send && $qframe && $qframe_last != $qframe) {
		my $qdistance;
		my $sdistance;
		# print STDERR $qseqid . "\n";
		if ($qframe_last>0 && $qframe>0) {
			$qdistance = $qstart - $qend_last - 1;
			$adjacent_start = $qend_last + 1;
			$adjacent_end = $qstart - 1;
		} elsif ($qframe_last<0 && $qframe<0) {
			$qdistance = $qend - $qstart_last - 1;
			$adjacent_start = $qstart_last + 1;
			$adjacent_end = $qend - 1;
		}
		$sdistance = $sstart - $send_last;
		# print STDERR $adjacent_start . "\n";
		if ($qdistance && $sdistance && $qdistance<=$frame_distance && $qdistance>0 && $sdistance <=3 && $sdistance>0) {
			if (int(abs($qframe_last/3))) {   #$qframe_last=3 or -3
				$qframe_last = 0;
			}
			$frameshifting_type = abs($qframe) - abs($qframe_last);
			# print STDERR $frameshifting_type . "\n";
			unless ($flag) {
				print OUT1 $line_last;
				print OUT1 $line;
			} else {
				print OUT1 $line;
			}
			$flag = 1;
			print OUT2 "$qseqid\t$adjacent_start\t$adjacent_end\t$frameshifting_type\n";
		} else {
			$flag = 0;
		}
	} else {
		$flag = 0;
	}
	$line_last = $line;
	$qseqid_last = $qseqid;
	$sseqid_last = $sseqid;
	$qstart_last = $qstart;
	$qend_last = $qend;
	$sstart_last = $sstart;
	$send_last = $send;
	$qframe_last = $qframe;
}
close FILE1;

print STDERR "\nJob finished!\n\n";
