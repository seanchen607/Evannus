#!/usr/bin/perl -w

=head1 Name

	09detect_joint_nanochromosome_gff3.pl

=head1 Description

This script was designed to:
	detect "joint" nanochromosomes (containing multiple genes on one nanochromosome) from GFF3 file.

=head1 Version

  Author: Xiao Chen, seanchen607@gmail.com
  Version: 1.0 Date: 2018/06/04

=head1 Usage

  perl 09detect_joint_nanochromosome_gff3.pl  <input_file>  <output_file1>  <output_file2>  <gap>

=head1 Example
  
  perl 09detect_joint_nanochromosome_gff3.pl  Euplotes_vannus_Mar2018.gff3  Euplotes_vannus_Mar2018_joint_nanochromosome_samestrand.gff3  Euplotes_vannus_Mar2018_joint_nanochromosome_diffstrand.gff3  100

=cut

# use strict;
die `pod2text $0` if (@ARGV != 4);

########################################################################
print STDERR "\nLoading gene data...\n";
open GENE,$ARGV[0];
my $gap=$ARGV[3];
my $last_contig;
my $last_end;
my $last_strand;
my $last_locus;
my $last_line;
my %joint_chr_strand;
my %joint_chr_lines;
my %joint_chr_flag;

while (<GENE>){
	my $line=$_;
	my @ar1=split /\t/, $_;
	if ($ar1[2] && $ar1[2] =~ /gene/){
		my $contig=$ar1[0];
		my $start=$ar1[3];
		my $end=$ar1[4];
		my $strand=$ar1[6];
		if ($last_contig && $last_end && $contig eq $last_contig && $start-$last_end>$gap) {
			$joint_chr_lines{$last_contig}.=$last_line unless $joint_chr_flag{$last_contig};
			$joint_chr_lines{$last_contig}.=$line;
			$joint_chr_flag{$last_contig}=1;
			if (eof) {
				$joint_chr_lines{$last_contig}.=$line;
			}
			if ($strand eq $last_strand) {
				$joint_chr_strand{$last_contig}=1 unless $joint_chr_strand{$last_contig};
			} else {
				$joint_chr_strand{$last_contig}=2 unless $joint_chr_strand{$last_contig};
			}
		}
		$last_contig=$contig;
		$last_end=$end;
		$last_strand=$strand;
		$last_line=$line;
	}
}
close GENE;
########################################################################
print STDERR "\nOutputing gene data with gene attributes...\n";
open OUT1,">$ARGV[1]";
open OUT2,">$ARGV[2]";

foreach $contig (sort keys %joint_chr_strand) {
	if ($joint_chr_strand{$contig} == 1) {
		print OUT1 $joint_chr_lines{$contig};
	} elsif ($joint_chr_strand{$contig} == 2) {
		print OUT2 $joint_chr_lines{$contig};
	}
}
########################################################################
print STDERR "\nJob finished!\n";
