#!/usr/bin/perl -w

=head1 Name

	06validation_gene_prediction_byRNAseq.pl

=head1 Description

	This script was designed to pick all targets with RNA-seq mapping to a new file.

=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2016/7/28

=head1 Usage

	perl 06validation_gene_prediction_byRNAseq.pl  <Gene data file>  <RNA-seq mapping list>  <Output file>

=head1 Example
  
	perl 06validation_gene_prediction_byRNAseq.pl  ./Strombidium_sulcatum_scaffolds.gene.fasta  ./gsnap.coordSorted.mapped.target.list ./Strombidium_sulcatum_scaffolds_RNAseqValid.fasta

=cut

use strict;
die `pod2text $0` if (@ARGV != 3);

#######################################

print STDERR "\nLoading Dataset...\n";
my $flag=0;
my %fasta;
my %data;
my $name;

############ Show Progress ############
open FILE1, $ARGV[0];
my $lines_total=0;

foreach (<FILE1>) {
	$lines_total++;
}
close FILE1;
my $lines=0;
my $percent2=0;
#######################################

open FILE1, $ARGV[0];
foreach (<FILE1>) {
	############ Show Progress ############
	$lines++;
	my $percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	$flag=1 if (/^\>/);        ####### $flag=1: FASTA mode; $flag=0: gff3 or similar mode
	if ($flag) {
		if (/^\>(.+?)\s/) {
			$name=$1;
		} else {
			chomp $_;
			$fasta{$name}.=$_;
		}
	} elsif (/^(.+?)\s/) {
		$name=$1;
		$data{$name}.=$_;
	}
}
close FILE1;

#######################################

print STDERR "\nPicking all targets with RNA-seq mapping to a new file...\n";

open OUT1, ">". $ARGV[2];

############ Show Progress ############
open FILE2, $ARGV[1];
$lines_total=0;

foreach (<FILE2>) {
	$lines_total++;
}
close FILE2;
$lines=0;
$percent2=0;
#######################################

open FILE2, $ARGV[1];
foreach (<FILE2>) {
	############ Show Progress ############
	$lines++;
	my $percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	my $target="";
	my $fpkm=0;
	if (/^(\w.+?)\t(\d.+)\s/) {
		$target=$1;
		$fpkm=$2;
		# print STDERR "$target\t$fpkm\n";
	}
	if ($fasta{$target} or $data{$target}) {
		if ($flag && $target) {
			print OUT1 "\>$target\n$fasta{$target}\n";
			# print STDERR "1\n";
		} else {
			print OUT1 $data{$target};
			# print STDERR "2\n";
		}
	}
}
close FILE2;

print STDERR "\nJob finished!\n\n";
