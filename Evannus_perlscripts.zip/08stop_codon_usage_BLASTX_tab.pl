#!/usr/bin/perl -w

=head1 Name

	08stop_codon_usage_BLASTX_tab.pl

=head1 Description

	This script was designed to analyze stop codon usage from a BLASTX tab file and a transcript FASTA file.

=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2018/1/2

=head1 Usage

	perl 08stop_codon_usage_BLASTX_tab.pl  <input_file1_transcript_FASTA>  <input_file2_BLASTX_tab>  <output_file1_stop_codon_usage>

=head1 Example
  
	perl 08stop_codon_usage_BLASTX_tab.pl  ./stringtie_merged_171016_EVJKLM_mRNA.fasta  ./stringtie_merged_171016_EVJKLM_mRNA_blastx_ciliate_sort.tab  ./stringtie_merged_171016_EVJKLM_mRNA_blastx_ciliate_sort_stop_codon.txt

=cut

use strict;
die `pod2text $0` if (@ARGV != 3);

#######################################

print STDERR "\nLoading transcript sequence data from FASTA file...\n";

############ Show Progress ############
my $lines_total;
my $lines;
my $percent;
my $percent2;
{
open FILE1, $ARGV[0];
foreach (<FILE1>) {
	$lines_total++;
}
close FILE1;
$lines=0;
$percent2=0;
}
#######################################

open FILE1, $ARGV[0];
my %fasta;
my $id="";
my $seq="";

foreach (<FILE1>) {
	############ Show Progress ############
	$lines++;
	$percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	if (/^\>/){
		$fasta{$id}=$seq if $id;
		# print STDERR $fasta{$id}."\n" if $id;
		# exit if $id;
		($id)=/^\>(.+?)[\r\n\s\t]/;
		# ($id)=/^\>(.+?)[\r\n]/;
		$seq="";
		next;
	} else {
		$_=~s/[\r\n\t\s]+//g;
		$seq.=$_;
	}
	$fasta{$id}=$seq if ($id && eof);
}
close FILE1;

#######################################

print STDERR "\nAnalyzing stop codon usage based on BLASTX tab file...\n";

open FILE2, $ARGV[1];
my %end_max;
my $count_taa;
my $count_tag;
# my $count_tga;

foreach (<FILE2>) {
	my @ar = split /\t/, $_;
	my $transcript = $ar[0];
	my $end = $ar[7];
	$end_max{$transcript} = 0 unless $end_max{$transcript};
	if ($fasta{$transcript} && $end_max{$transcript} < $end) {
		$end_max{$transcript} = $end;
	}
}
close FILE2;

foreach my $transcript (keys %end_max) {
	my $rest = substr($fasta{$transcript}, $end_max{$transcript});
	# print STDERR $fasta{$transcript_last}."\n";
	# exit;
	for (my $i=0; $i<length($rest)-1; $i=$i+3) {
		my $codon = substr($rest, $i, 3);
		if ($codon =~ /TAA/i) {
			$count_taa++;
			goto FLAG;
		}
		if ($codon =~ /TAG/i) {
			$count_tag++;
			goto FLAG;
		}
		# if ($codon =~ /TGA/i) {
			# $count_tga++;
		# }
	}
	FLAG:
}
#######################################

print STDERR "\nOutputting stop codon usage...\n";
open OUT, ">".$ARGV[2];
print OUT "Stop codon usage:\nTAA\t$count_taa\nTAG\t$count_tag\n";

#######################################

print STDERR "\nJob finished!\n\n";
