#!/usr/bin/perl -w

=head1 Name

	05list_sam_mapped_targets.pl

=head1 Description

	This script was designed to list all mapped targets and their FPKM value from the mapping output SAM file.

=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2016/7/28

=head1 Usage

	perl 05list_sam_mapped_targets.pl <SAM file>

=head1 Example
  
	perl 05list_sam_mapped_targets.pl ./gsnap.coordSorted.mapped.sam

=cut

use strict;
die `pod2text $0` if (@ARGV != 1);


print STDERR "\nListing all mapped targets and their FPKM value from the mapping output SAM file...\n";
my $reads_total=0;
my %target_len;

############ Show Progress ############
my $lines_total=0;
open FILE1,$ARGV[0];
foreach (<FILE1>) {
	if (/^\@SQ	SN\:(.+?)\tLN\:(\d+)/) {
		$target_len{$1}=$2;
	} else {
		$reads_total++;
	}
	$lines_total++;
}
close FILE1;
my $lines=0;
my $percent2=0;
#######################################

open FILE1, $ARGV[0];
$ARGV[0]=~s/\.\w+$//;

open OUT1, ">". "$ARGV[0].target.list";
my %target_fragments;
my $mapped_reads_M=$reads_total/1000000;       # unit: Million

while (<FILE1>) {
	############ Show Progress ############
	$lines++;
	my $percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	
	my @ar=split "\t", $_ if $_ !~ /^\@/;
	
	if ($ar[2] && $ar[8]>=0) {
		my $target=$ar[2];
		$target_fragments{$target}++;
	}
}
close FILE1;

print OUT1 "Target\tFPKM\n";
foreach my $target (sort keys %target_fragments) {
	if ($target_fragments{$target}) {
		# print STDOUT "$target\t$target_len{$target}\n";
		my $loci_len_kb=$target_len{$target}/1000;       # unit: kb
		my $fpkm=sprintf("%0.2f", $target_fragments{$target}/($mapped_reads_M*$loci_len_kb));
		print OUT1 "$target\t$fpkm\n";
	}
}
		
print STDERR "\nJob finished!\n\n";
