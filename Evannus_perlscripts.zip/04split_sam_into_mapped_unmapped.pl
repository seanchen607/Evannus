#!/usr/bin/perl -w

=head1 Name

	split_sam_into_mapped_unmapped.pl

=head1 Description

	This script was designed to split mapping output SAM file into "mapped.sam" and "unmapped.sam".

=head1 Version

	Author: Xiao Chen, seanchen607@gmail.com
	Version: 1.0 Date: 2016/7/28

=head1 Usage

	perl split_sam_into_mapped_unmapped.pl <SAM file>

=head1 Example
  
	perl split_sam_into_mapped_unmapped.pl ./gsnap.coordSorted.sam

=cut

use strict;
die `pod2text $0` if (@ARGV != 1);


print STDERR "\nSplitting SAM file into mapped.sam and unmapped.sam...\n";

############ Show Progress ############
my $lines_total=0;
open FILE1,$ARGV[0];
foreach (<FILE1>) {
	$lines_total++;
}
close FILE1;
my $lines=0;
my $percent2=0;
#######################################

open FILE1, $ARGV[0];
$ARGV[0]=~s/\.\w+$//;

open OUT1, ">". "$ARGV[0].mapped.sam";
open OUT2, ">". "$ARGV[0].unmapped.sam";

while (<FILE1>) {
	############ Show Progress ############
	$lines++;
	my $percent=int(100*$lines/$lines_total);
	if ($percent2<$percent){
		$percent2=$percent;
		print STDOUT "$percent2\%\n";
	}
	#######################################
	
	my @ar=split "\t", $_ if /\t/;
	
	if (/^\@/) {
		print OUT1 $_;
		print OUT2 $_;		
	} elsif ($ar[2]~~/\w+/) {
		print OUT1 $_;
	} else {
		print OUT2 $_;
	}
}
close FILE1;

print STDERR "\nJob finished!\n\n";
